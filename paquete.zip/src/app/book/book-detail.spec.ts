import { BookDetail } from './book-detail';

