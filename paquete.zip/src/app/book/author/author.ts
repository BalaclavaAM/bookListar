export class Author {
  name: String;
}
